// let fs = require('fs'); //Define the file stream for file attachments
// var express = require('express');
// var app = express();
// const catalyst = require('zcatalyst-sdk-node');

// //Create a config object with the email configuration
// let config = {
//     from_email: 'srkeshav7@gmail.com', 
//     to_email: ["kingkeshav7@gmail.com",], 
//     // cc:["p.boyle@zylker.com","robert.plant@zylker.com"], 
//     // bcc:["ham.gunn@zylker.com","rover.jenkins@zylker.com"],
//     // reply_to:["peter.d@zoho.com","arnold.h@zoho.com"],
//     html_mode: true,
//     subject: 'Greetings from Zylker Corp!',
//     content: "<p>Hello,</p> We're glad to welcome you at Zylker Corp. To begin your journey with us, please download the attached KYC form and fill in your details. You can send us the completed form to this same email address.</p>We cannot wait to get started!<p><p>Cheers!</p><p>Team Zylker</p>",
// 	attachments: [fs.createReadStream('kycform.pdf')] //create a file stream for the file attachment
// };
// // var catalystApp = CatalystApp
// var catalystApp = catalyst.initialize()
// let email = catalystApp.email();
// let mailPromise = email.sendMail(config);
//     mailPromise.then((mailObject) => {
//         console.log(mailObject);
//     })
// 	.catch((err) => {
// 		context.log(err);
// 	});

// module.exports = (context, basicIO) => {
// 	/* 
//         BASICIO FUNCTIONALITIES
//     */
// 	basicIO.write('Hello from index.js'); //response stream (accepts only string, throws error if other than string)
// 	basicIO.getArgument('argument1'); // returns QUERY_PARAM[argument1] || BODY_JSON[argument1] (takes argument from query and body, first preference to query)
// 	/* 
//         CONTEXT FUNCTIONALITIES
//     */
// 	console.log('successfully executed basicio functions');
// 	context.close(); //end of application
// };


var express = require('express');
var app = express();
var catalyst = require('zcatalyst-sdk-node');
app.use(express.json());
const tableName = 'AlienCity'; // The table created in the Data Store
const columnName = 'CityName'; // The column created in the table

// // The POST API that reports the alien encounter for a particular city


app.get("/email", (req, res)=>{
	var catalystApp = catalyst.initialize(req)
	// const catalyst = require('zcatalyst-sdk-node');

//Create a config object with the email configuration
let config = {
    from_email: 'srkeshav7@gmail.com', 
    to_email: ["kingkeshav7@gmail.com",], 
    // cc:["p.boyle@zylker.com","robert.plant@zylker.com"], 
    // bcc:["ham.gunn@zylker.com","rover.jenkins@zylker.com"],
    // reply_to:["peter.d@zoho.com","arnold.h@zoho.com"],
    html_mode: true,
    subject: 'Greetings from Zylker Corp!',
    content: "<p>Hello,</p> We're glad to welcome you at Zylker Corp. To begin your journey with us, please download the attached KYC form and fill in your details. You can send us the completed form to this same email address.</p>We cannot wait to get started!<p><p>Cheers!</p><p>Team Zylker</p>"//create a file stream for the file attachment
};
let email = catalystApp.email();
let mailPromise = email.sendMail(config);
mailPromise.then((mailObject) => {
	console.log(mailObject);
	res.send("Success")
		context.close();
}).catch((err) => {
	console.log(err);
	res.send("Failure")
	context.close();
});
})


// app.post('/alien', (req, res) => {
//  var cityJson = req.body;
// console.log(cityJson);
//  // Initializing Catalyst SDK
//  var catalystApp = catalyst.initialize(req);
//  // Queries the Catalyst Data Store table and checks whether a row is present for the given city
//  getDataFromCatalystDataStore(catalystApp, cityJson.city_name).then(cityDetails => {
//   if (cityDetails.length == 0) { // If the row is not present, then a new row is inserted
//    console.log("Alien alert!"); //Written to the logs. You can view this log from Logs under the Monitor section in the console 
//    var rowData={}
//    rowData[columnName]=cityJson.city_name;

//   var rowArr=[];
//   rowArr.push(rowData);
//    // Inserts the city name as a row in the Catalyst Data Store table
//    catalystApp.datastore().table(tableName).insertRows(rowArr).then(cityInsertResp => {
//     res.send({
//      "message": "Thanks for reporting!"
//     });
//    }).catch(err => {
//     console.log(err);
//     sendErrorResponse(res);
//    })
//   } else { // If the row is present, then a message is sent indicating duplication
//    res.send({
//     "message": "Looks like you are not the first person to encounter aliens in this city! Someone has already reported an alien encounter here!"
//    });
//   }
//  }).catch(err => {
//   console.log(err);
//   sendErrorResponse(res);
//  })
// });

// // The GET API that checks the table for an alien encounter in that city 
// app.get('/alien', (req, res) => {
//  var city = req.query.city_name;

//  // Initializing Catalyst SDK
//  var catalystApp = catalyst.initialize(req);

//  // Queries the Catalyst Data Store table and checks whether a row is present for the given city
//  getDataFromCatalystDataStore(catalystApp, city).then(cityDetails => {
//   if (cityDetails.length == 0) {
//    res.send({
//     "message": "Hurray! No alien encounters in this city yet!",
//     "signal": "negative"
//    });
//   } else {
//    res.send({
//     "message": "Uh oh! Looks like there are aliens in this city!",
//     "signal": "positive"
//    });
//   }
//  }).catch(err => {
//   console.log(err);
//   sendErrorResponse(res);
//  })
// });
// /**
//  * Checks whether an alien encounter is already reported for the given city by querying the Data Store table
//  * @param {*} catalystApp 
//  * @param {*} cityName 
//  */
// function getDataFromCatalystDataStore(catalystApp, cityName) {
//  return new Promise((resolve, reject) => {
//   // Queries the Catalyst Data Store table
//   catalystApp.zcql().executeZCQLQuery("Select * from "+tableName+" where "+columnName+"='" + cityName + "'").then(queryResponse => {
//    resolve(queryResponse);
//   }).catch(err => {
//    reject(err);
//   })
//  });

// }

// /**
//  * Sends an error response
//  * @param {*} res 
//  */
// function sendErrorResponse(res) {
//  res.status(500);
//  res.send({
//   "error": "Internal server error occurred. Please try again in some time."
//  });
// }
module.exports = app;

// let query = 'SELECT Email FROM sales where Price > 3000 limit 5' ;
// let zcql = catalystApp.zcql();
// let zcqlPromise = zcql.executeZCQLQuery(query);
// zcqlPromise.then(queryResult => {
//     console.log(queryResult);
//     var emailID = [];
//     for(i=0;i<queryResult.length;i++){
//         emailID.push(queryResult[i].sales.Email);
//     }

// console.log(emailID)
// // basicIO.write(emailID)
//     let email = catalystApp.email();
//     let config = {
//     from_email: 'srkeshav7@gmail.com',
//     to_email: "kingkeshav7@gmail.com", 
//     html_mode: true,
//     subject: 'ANNOUNCEMENT!',
//     content: "<p>Hello,</p> We're glad to Introduce our new product.<p>Team 21</p>",
// };


// let mailPromise = email.sendMail(config);
//     mailPromise.then((mailObject) => {
//         console.log(mailObject);
//         basicIO.write(mailObject)
//             context.close();
//     }).catch((err) => {
//         console.log(err);
//         basicIO.write(err)
//         context.close();
//     });
// }).catch((err) => {
//         console.log(err);
//         basicIO.write(err)
//         context.close();
//     });
// //Create a config object with the email configuration

